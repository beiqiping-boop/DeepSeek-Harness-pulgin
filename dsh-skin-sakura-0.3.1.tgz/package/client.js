/* dsh-skin-sakura —— 浏览器端 bundle（也是源码，直接改这个文件）。
 *
 * - 中栏铺背景（工作区对话 + 首页），左栏 / 窗口标题栏 / 右侧面板不动；
 * - 在「设置 → 插件 → 背景皮肤」里可开关、调强度 / 模糊 / 取景、上传自己的图；
 * - 默认背景是内置渐变（不含任何图片资源），配置存在本机 localStorage，不联网、不上传。
 */
window.__ModuleLoader__.load({
  id: 'dsh-skin-sakura',
  factory: (require) => {
    const React = require('react')
    const h = React.createElement

    const KEY = 'dsh-skin-sakura:v1'
    const IMG_KEY = 'dsh-skin-sakura:image'
    const DEFAULTS = { enabled: true, clarity: 70, blur: 1.2, posX: 50, posY: 40, darkFollow: true }

    const clamp = (v, a, b) => Math.min(b, Math.max(a, Number(v) || 0))

    function loadCfg() {
      try {
        const raw = localStorage.getItem(KEY)
        const v = raw ? JSON.parse(raw) : {}
        return Object.assign({}, DEFAULTS, v && typeof v === 'object' ? v : {})
      } catch (e) {
        return Object.assign({}, DEFAULTS)
      }
    }
    function saveCfg(cfg) {
      try {
        localStorage.setItem(KEY, JSON.stringify(cfg))
      } catch (e) {
        /* 存不下就只在本次会话生效 */
      }
    }
    function loadImage() {
      try {
        return localStorage.getItem(IMG_KEY) || ''
      } catch (e) {
        return ''
      }
    }

    /* ---------------- 背景层 ---------------- */
    /* 默认背景：纯白（与 DSH 原生一致）。没选图时插件等于"什么都没换"，
     * 选了图才变成自定义背景。 */
    const WHITE_ART = 'linear-gradient(#ffffff, #ffffff)'

    const artLayers = (image) => (image ? 'url("' + image + '")' : WHITE_ART)

    const rgba = (a) => 'rgba(255, 255, 255, ' + a.toFixed(3) + ')'
    const rgbaDark = (a) => 'rgba(12, 14, 18, ' + a.toFixed(3) + ')'

    function buildCss(cfg, image) {
      if (!cfg.enabled) return ''
      const clarity = clamp(cfg.clarity, 0, 100)
      const mid = 0.92 - 0.004 * clarity
      const top = Math.min(0.985, mid + 0.26)
      const bot = Math.min(0.985, mid + 0.12)
      const blur = clamp(cfg.blur, 0, 12)
      const posX = clamp(cfg.posX, 0, 100)
      const posY = clamp(cfg.posY, 0, 100)
      const dark = cfg.darkFollow
        ? [
            'body[data-ds-dark-theme] div[class*="_centerCol"]::before {',
            '  background-image:',
            '    linear-gradient(180deg,',
            '      ' + rgbaDark(Math.min(0.99, mid + 0.30)) + ' 0%,',
            '      ' + rgbaDark(Math.min(0.99, mid + 0.18)) + ' 18%,',
            '      ' + rgbaDark(Math.min(0.99, mid + 0.14)) + ' 55%,',
            '      ' + rgbaDark(Math.min(0.99, mid + 0.22)) + ' 100%),',
            '    ' + artLayers(image) + ';',
            '}',
          ].join('\n')
        : ''

      return [
        'div[class*="_centerCol"] {',
        '  position: relative;',
        '  isolation: isolate;',
        '  background: transparent !important;',
        '}',
        'div[class*="_centerCol"]::before {',
        '  content: "";',
        '  position: absolute;',
        '  inset: 0;',
        '  z-index: -1;',
        '  pointer-events: none;',
        '  filter: blur(' + blur + 'px) saturate(1.02);',
        '  transform: scale(1.03);',
        '  background-image:',
        '    linear-gradient(180deg,',
        '      ' + rgba(top) + ' 0%,',
        '      ' + rgba(Math.max(0, mid - 0.02)) + ' 18%,',
        '      ' + rgba(mid) + ' 55%,',
        '      ' + rgba(bot) + ' 100%),',
        '    ' + artLayers(image) + ';',
        '  background-size: cover, cover;',
        '  background-position: center top, ' + posX + '% ' + posY + '%;',
        '  background-repeat: no-repeat, no-repeat;',
        '}',
        '',
        'header[class*="_header"],',
        'div[data-phase],',
        'div[class*="_scrollBody"],',
        'div[class*="_composerSeat"],',
        'div[class*="_centerCol"] [class*="hero"],',
        'div[class*="_centerCol"] [class*="Hero"] {',
        '  background: transparent !important;',
        '}',
        dark,
      ].join('\n')
    }

    let skinStyle = null
    function applySkin(cfg, image) {
      if (!skinStyle) return
      try {
        skinStyle.textContent = buildCss(cfg, image)
      } catch (e) {
        skinStyle.textContent = ''
      }
    }

    /* ---------------- 设置页样式 ---------------- */
    const CSS = [
      '[data-sk-page]{display:flex;flex-direction:column;gap:18px;padding:2px 2px 8px;max-width:640px;}',
      '[data-sk-sec]{display:flex;flex-direction:column;gap:8px;}',
      '[data-sk-h]{font-size:11px;font-weight:600;letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9aa0a6);}',
      '[data-sk-row]{display:flex;align-items:center;gap:10px;}',
      '[data-sk-grow]{flex:1;min-width:0;}',
      '[data-sk-label]{font-size:13px;}',
      '[data-sk-note]{font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary,#9aa0a6);}',
      '[data-sk-sw]{flex:none;width:38px;height:22px;border-radius:11px;border:0;cursor:pointer;position:relative;',
      '  background:var(--dsw-alias-interactive-bg-hover,rgba(128,128,128,.35));transition:background .15s;padding:0;}',
      '[data-sk-sw][data-on]{background:#3b82f6;}',
      '[data-sk-sw] i{position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;',
      '  transition:left .15s;display:block;}',
      '[data-sk-sw][data-on] i{left:19px;}',
      '[data-sk-range]{flex:none;width:200px;accent-color:#3b82f6;cursor:pointer;}',
      '[data-sk-val]{flex:none;width:52px;text-align:right;font-size:12px;font-variant-numeric:tabular-nums;',
      '  color:var(--dsw-alias-label-secondary,#6b7280);}',
      '[data-sk-btn]{padding:6px 12px;border-radius:8px;font-size:12px;cursor:pointer;',
      '  border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));',
      '  background:var(--dsw-alias-interactive-bg,rgba(128,128,128,.08));',
      '  color:var(--dsw-alias-label-primary,inherit);}',
      '[data-sk-btn]:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(128,128,128,.16));}',
      '[data-sk-thumb]{width:168px;height:94px;border-radius:10px;object-fit:cover;display:block;flex:none;',
      '  border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));}',
      '[data-sk-msg]{font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary,#6b7280);}',
      '[data-sk-msg][data-bad]{color:#d93025;}',
      '[data-sk-disabled]{opacity:.45;pointer-events:none;}',
    ].join('\n')

    /* ---------------- 组件 ---------------- */
    function ToggleRow(props) {
      return h('div', { 'data-sk-row': '' },
        h('div', { 'data-sk-grow': '' },
          h('div', { 'data-sk-label': '' }, props.label),
          props.note ? h('div', { 'data-sk-note': '' }, props.note) : null),
        h('button', {
          'data-sk-sw': '',
          'data-on': props.on ? '' : undefined,
          onClick: function () { props.onChange(!props.on) },
          'aria-pressed': props.on ? 'true' : 'false',
        }, h('i')),
      )
    }

    function SliderRow(props) {
      return h('div', { 'data-sk-row': '' },
        h('div', { 'data-sk-grow': '' },
          h('div', { 'data-sk-label': '' }, props.label),
          props.note ? h('div', { 'data-sk-note': '' }, props.note) : null),
        h('input', {
          'data-sk-range': '',
          type: 'range',
          min: props.min, max: props.max, step: props.step,
          value: props.value,
          onChange: function (e) { props.onChange(Number(e.target.value)) },
        }),
        h('span', { 'data-sk-val': '' }, props.display),
      )
    }

    function Panel() {
      const [cfg, setCfg] = React.useState(loadCfg)
      const [img, setImg] = React.useState(loadImage)
      const [msg, setMsg] = React.useState('')
      const [bad, setBad] = React.useState(false)
      const fileRef = React.useRef(null)

      const say = (t, isBad) => { setMsg(t); setBad(Boolean(isBad)) }
      const custom = Boolean(img)

      const patch = (p, label) => {
        setCfg((prev) => {
          const next = Object.assign({}, prev, p)
          saveCfg(next)
          applySkin(next, img)
          if (label) say(label + '：已保存')
          return next
        })
      }

      const useImage = (url, note) => {
        setImg(url)
        applySkin(cfg, url)
        say(note || '图片已更新')
      }

      const onFile = (file) => {
        if (!file) return
        if (!/^image\//.test(file.type)) { say('这不是图片文件', true); return }
        say('正在处理图片…')
        const fr = new FileReader()
        fr.onerror = () => say('读不出这个文件', true)
        fr.onload = () => {
          const im = new Image()
          im.onerror = () => say('这张图解不开', true)
          im.onload = () => {
            try {
              const max = 2048
              const scale = Math.min(1, max / Math.max(im.width, im.height))
              const w = Math.max(1, Math.round(im.width * scale))
              const hh = Math.max(1, Math.round(im.height * scale))
              const c = document.createElement('canvas')
              c.width = w
              c.height = hh
              c.getContext('2d').drawImage(im, 0, 0, w, hh)
              const url = c.toDataURL('image/jpeg', 0.86)
              const kb = Math.round(url.length / 1024)
              try {
                localStorage.setItem(IMG_KEY, url)
              } catch (e) {
                useImage(url, '图片已应用，但太大存不下（' + kb + 'KB），重启后回默认')
                return
              }
              useImage(url, '图片已更新（' + w + '×' + hh + '，' + kb + 'KB）')
            } catch (e) {
              say('处理图片失败：' + e.message, true)
            }
          }
          im.src = fr.result
        }
        fr.readAsDataURL(file)
      }

      const resetImage = () => {
        try { localStorage.removeItem(IMG_KEY) } catch (e) { /* noop */ }
        useImage('', '已恢复默认（白色）')
        if (fileRef.current) fileRef.current.value = ''
      }

      return h('div', { 'data-sk-page': '' },
        h('div', { 'data-sk-sec': '' },
          h(ToggleRow, {
            label: '启用背景',
            note: '只影响中间那一栏（工作区 / 首页）；关掉就回到 DSH 原来的样子。',
            on: cfg.enabled,
            onChange: (v) => patch({ enabled: v }, v ? '已启用' : '已关闭'),
          })),

        h('div', { 'data-sk-sec': '', 'data-sk-disabled': cfg.enabled ? undefined : '' },
          h('div', { 'data-sk-h': '' }, '观感'),
          h(SliderRow, {
            label: '图片强度', note: '越大图越清楚，字越吃力',
            min: 0, max: 100, step: 5, value: cfg.clarity,
            display: cfg.clarity + '%',
            onChange: (v) => patch({ clarity: v }),
          }),
          h(SliderRow, {
            label: '模糊', note: '0 = 完全不糊',
            min: 0, max: 8, step: 0.4, value: cfg.blur,
            display: Number(cfg.blur).toFixed(1),
            onChange: (v) => patch({ blur: v }),
          }),
          h(ToggleRow, {
            label: '深色主题下自动变暗',
            note: '深色皮肤时把白薄纱换成深色，避免糊成一片',
            on: cfg.darkFollow,
            onChange: (v) => patch({ darkFollow: v }),
          })),

        h('div', { 'data-sk-sec': '', 'data-sk-disabled': cfg.enabled ? undefined : '' },
          h('div', { 'data-sk-h': '' }, '取景'),
          h(SliderRow, {
            label: '水平位置', min: 0, max: 100, step: 1, value: cfg.posX,
            display: cfg.posX + '%',
            onChange: (v) => patch({ posX: v }),
          }),
          h(SliderRow, {
            label: '垂直位置', min: 0, max: 100, step: 1, value: cfg.posY,
            display: cfg.posY + '%',
            onChange: (v) => patch({ posY: v }),
          })),

        h('div', { 'data-sk-sec': '' },
          h('div', { 'data-sk-h': '' }, '背景图'),
          h('div', { 'data-sk-row': '', style: { alignItems: 'flex-start' } },
            custom
              ? h('img', {
                  'data-sk-thumb': '',
                  src: img,
                  alt: '',
                  onError: function (e) { e.target.style.opacity = '0.3' },
                })
              : h('div', { 'data-sk-thumb': '', style: { backgroundImage: WHITE_ART } }),
            h('div', { 'data-sk-grow': '', style: { display: 'flex', flexDirection: 'column', gap: '8px' } },
              h('div', { 'data-sk-note': '' }, custom ? '当前：你自己的图片' : '当前：默认白色'),
              h('div', { 'data-sk-row': '', style: { gap: '8px' } },
                h('button', { 'data-sk-btn': '', onClick: () => fileRef.current && fileRef.current.click() },
                  custom ? '换一张…' : '选择图片…'),
                custom ? h('button', { 'data-sk-btn': '', onClick: resetImage }, '恢复默认') : null),
              h('input', {
                ref: fileRef,
                type: 'file',
                accept: 'image/*',
                style: { display: 'none' },
                onChange: function (e) { onFile(e.target.files && e.target.files[0]) },
              }),
              h('div', { 'data-sk-note': '' },
                '图片会缩到 2048px 以内并只存在本机，不会上传。')))),

        msg ? h('div', { 'data-sk-msg': '', 'data-bad': bad ? '' : undefined }, msg) : null,

        h('div', { 'data-sk-note': '' }, '配置保存在本机浏览器里（localStorage），换设备不会同步。'),
      )
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        skinStyle = document.createElement('style')
        skinStyle.id = 'dsh-skin-sakura:styles'
        document.head.appendChild(skinStyle)
        applySkin(loadCfg(), loadImage())

        const uiStyle = document.createElement('style')
        uiStyle.setAttribute('data-plugin-css', 'dsh-skin-sakura')
        uiStyle.textContent = CSS
        document.head.appendChild(uiStyle)

        if (ctx && typeof ctx.effect === 'function') {
          ctx.effect(() => () => {
            skinStyle.remove()
            uiStyle.remove()
          }, 'dsh-skin-sakura: 背景样式')
        }

        const slots = (typeof ctx.get === 'function' ? ctx.get('slots') : undefined) || ctx.slots
        if (!slots) return
        try {
          slots.inject('settings.section', () => slots.register(
            { name: 'settings.section', id: 'skin-sakura', order: 40, label: '背景皮肤' },
            () => h(Panel),
          ))
        } catch (e) {
          /* 设置页挂不上不影响背景本身 */
          console.warn('[dsh-skin-sakura] 设置页注册失败：', e)
        }
      },
    }
  },
})
