export const name = 'dsh-skin-sakura'

export const inject = []

export function apply() {
  // 纯前端插件：宿主侧不需要做任何事，样式由 ./client 在浏览器里注入。
}
